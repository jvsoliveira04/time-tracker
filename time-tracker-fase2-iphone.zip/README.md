# Meu Ponto - Controle Pessoal de Ponto de Trabalho

Aplicativo web pessoal para registrar e acompanhar suas marcações de ponto. Ele **não substitui o sistema oficial da empresa**.

## Status

**Fase 2 — Banco local + PWA**

- React + TypeScript + Vite
- Dexie.js + IndexedDB para salvar as marcações no aparelho
- Marcações separadas por dia
- PWA preparado para instalação no iPhone
- GitHub Actions preparado para publicar no GitHub Pages

## Rodar localmente

```bash
npm install
npm run dev
```

Para validar o projeto:

```bash
npm run type-check
npm run build
```

## Publicar no GitHub Pages

1. Envie o projeto para a branch `main`.
2. No GitHub, abra **Settings → Pages**.
3. Em **Build and deployment → Source**, selecione **GitHub Actions**.
4. Faça um novo push ou execute manualmente o workflow **Deploy to GitHub Pages**.
5. Depois que o workflow terminar, o GitHub mostrará a URL publicada.

O projeto usa `base: './'`, então funciona como site de projeto no GitHub Pages sem precisar alterar o código para o nome do repositório.

## Instalar no iPhone

Depois que o GitHub Pages estiver publicado:

1. Abra a URL do app no **Safari** do iPhone.
2. Toque em **Compartilhar**.
3. Escolha **Adicionar à Tela de Início**.
4. Confirme em **Adicionar**.
5. Abra o ícone **Meu Ponto** pela tela inicial.

As marcações são armazenadas localmente no navegador do aparelho usando IndexedDB. Por isso, os dados deste app são locais ao dispositivo/navegador e não ficam sincronizados automaticamente com outro aparelho.

## Estrutura principal

```text
src/
├── App.tsx       # Interface e fluxo das marcações
├── db.ts         # Banco IndexedDB via Dexie
├── types.ts      # Tipos TypeScript
├── App.css
├── index.css
└── main.tsx

public/
├── icons/
│   ├── icon-192.png
│   └── icon-512.png
├── manifest.json
└── sw.js

.github/
└── workflows/
    └── deploy.yml
```

## Próxima etapa

- Cálculo de horas trabalhadas
- Saldo diário considerando a jornada configurada
- Histórico por data
- Edição/exclusão segura de marcações
- Resumo semanal/mensal
- Comprovante das marcações
