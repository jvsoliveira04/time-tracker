export type TimeEntryType = 'Entrada' | 'Almoço' | 'Retorno' | 'Saída'

export interface TimeEntry {
  id?: number
  type: TimeEntryType
  timestamp: number
  date: string // YYYY-MM-DD in the device's local timezone
}
